﻿Public Class Form1
    ' Declare variables for calculations
    Dim Total As Double
    Dim Average As Double
    Dim Grade As String
    Dim Remarks As String

    ' Button click event to calculate total, average, grade, and remarks
    Private Sub ButtonCalculate_Click(sender As Object, e As EventArgs) Handles ButtonCalculate.Click
        ' Check if any TextBox is empty
        If String.IsNullOrWhiteSpace(TextBoxSubject1.Text) OrElse
           String.IsNullOrWhiteSpace(TextBoxSubject2.Text) OrElse
           String.IsNullOrWhiteSpace(TextBoxSubject3.Text) OrElse
           String.IsNullOrWhiteSpace(TextBoxSubject4.Text) OrElse
           String.IsNullOrWhiteSpace(TextBoxSubject5.Text) Then
            MessageBox.Show("Please enter marks for all subjects.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit the method without proceeding further
        End If

        ' Check if all entered values are valid numbers
        If Not IsNumeric(TextBoxSubject1.Text) OrElse
           Not IsNumeric(TextBoxSubject2.Text) OrElse
           Not IsNumeric(TextBoxSubject3.Text) OrElse
           Not IsNumeric(TextBoxSubject4.Text) OrElse
           Not IsNumeric(TextBoxSubject5.Text) Then
            MessageBox.Show("Please enter valid numeric marks for all subjects.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' Exit the method without proceeding further
        End If

        ' Input marks from textboxes and convert them to Double
        Dim Subject1 As Double = Val(TextBoxSubject1.Text)
        Dim Subject2 As Double = Val(TextBoxSubject2.Text)
        Dim Subject3 As Double = Val(TextBoxSubject3.Text)
        Dim Subject4 As Double = Val(TextBoxSubject4.Text)
        Dim Subject5 As Double = Val(TextBoxSubject5.Text)

        ' Calculate total and average
        Total = Subject1 + Subject2 + Subject3 + Subject4 + Subject5
        Average = Total / 5

        ' Determine grade and remarks based on average marks
        Select Case Average
            Case >= 90
                Grade = "A"
                Remarks = "Excellent"
            Case 75 To 89
                Grade = "B"
                Remarks = "Very Good"
            Case 60 To 74
                Grade = "C"
                Remarks = "Good"
            Case 50 To 59
                Grade = "D"
                Remarks = "Pass"
            Case Else
                Grade = "F"
                Remarks = "Fail"
        End Select

        ' Display results in the corresponding textboxes
        TextBoxTotal.Text = Total.ToString()
        TextBoxAverage.Text = Format(Average, "0.00")
        TextBoxGrade.Text = Grade
        TextBoxRemarks.Text = Remarks
    End Sub

    ' Button click event to exit the application
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        Me.Close() ' Close the application
    End Sub
End Class
