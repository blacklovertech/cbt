﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        GradeLabel = New Label()
        TextBoxSubject1 = New TextBox()
        TextBoxSubject2 = New TextBox()
        TextBoxSubject3 = New TextBox()
        TextBoxSubject4 = New TextBox()
        TextBoxSubject5 = New TextBox()
        TextBoxTotal = New TextBox()
        TextBoxAverage = New TextBox()
        TextBoxGrade = New TextBox()
        ButtonCalculate = New Button()
        ButtonExit = New Button()
        TextBoxRemarks = New TextBox()
        LabelRemarks = New Label()
        Label8 = New Label()
        PictureBox1 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(116, 113)
        Label1.Name = "Label1"
        Label1.Size = New Size(55, 15)
        Label1.TabIndex = 0
        Label1.Text = "Subject 1"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(116, 161)
        Label2.Name = "Label2"
        Label2.Size = New Size(55, 15)
        Label2.TabIndex = 1
        Label2.Text = "Subject 2"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(116, 214)
        Label3.Name = "Label3"
        Label3.Size = New Size(55, 15)
        Label3.TabIndex = 2
        Label3.Text = "Subject 3"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(116, 267)
        Label4.Name = "Label4"
        Label4.Size = New Size(55, 15)
        Label4.TabIndex = 3
        Label4.Text = "Subject 4"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(116, 319)
        Label5.Name = "Label5"
        Label5.Size = New Size(55, 15)
        Label5.TabIndex = 4
        Label5.Text = "Subject 5"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(500, 121)
        Label6.Name = "Label6"
        Label6.Size = New Size(32, 15)
        Label6.TabIndex = 5
        Label6.Text = "Total"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(482, 177)
        Label7.Name = "Label7"
        Label7.Size = New Size(50, 15)
        Label7.TabIndex = 6
        Label7.Text = "Average"
        ' 
        ' GradeLabel
        ' 
        GradeLabel.AutoSize = True
        GradeLabel.Location = New Point(482, 246)
        GradeLabel.Name = "GradeLabel"
        GradeLabel.Size = New Size(38, 15)
        GradeLabel.TabIndex = 7
        GradeLabel.Text = "Grade"
        ' 
        ' TextBoxSubject1
        ' 
        TextBoxSubject1.Location = New Point(271, 113)
        TextBoxSubject1.Name = "TextBoxSubject1"
        TextBoxSubject1.Size = New Size(100, 23)
        TextBoxSubject1.TabIndex = 8
        ' 
        ' TextBoxSubject2
        ' 
        TextBoxSubject2.Location = New Point(271, 161)
        TextBoxSubject2.Name = "TextBoxSubject2"
        TextBoxSubject2.Size = New Size(100, 23)
        TextBoxSubject2.TabIndex = 9
        ' 
        ' TextBoxSubject3
        ' 
        TextBoxSubject3.Location = New Point(271, 214)
        TextBoxSubject3.Name = "TextBoxSubject3"
        TextBoxSubject3.Size = New Size(100, 23)
        TextBoxSubject3.TabIndex = 10
        ' 
        ' TextBoxSubject4
        ' 
        TextBoxSubject4.Location = New Point(271, 259)
        TextBoxSubject4.Name = "TextBoxSubject4"
        TextBoxSubject4.Size = New Size(100, 23)
        TextBoxSubject4.TabIndex = 11
        ' 
        ' TextBoxSubject5
        ' 
        TextBoxSubject5.Location = New Point(271, 311)
        TextBoxSubject5.Name = "TextBoxSubject5"
        TextBoxSubject5.Size = New Size(100, 23)
        TextBoxSubject5.TabIndex = 12
        ' 
        ' TextBoxTotal
        ' 
        TextBoxTotal.ForeColor = Color.Red
        TextBoxTotal.Location = New Point(590, 121)
        TextBoxTotal.Name = "TextBoxTotal"
        TextBoxTotal.ReadOnly = True
        TextBoxTotal.Size = New Size(100, 23)
        TextBoxTotal.TabIndex = 13
        ' 
        ' TextBoxAverage
        ' 
        TextBoxAverage.ForeColor = Color.Red
        TextBoxAverage.Location = New Point(590, 169)
        TextBoxAverage.Name = "TextBoxAverage"
        TextBoxAverage.ReadOnly = True
        TextBoxAverage.Size = New Size(100, 23)
        TextBoxAverage.TabIndex = 14
        ' 
        ' TextBoxGrade
        ' 
        TextBoxGrade.ForeColor = Color.Red
        TextBoxGrade.Location = New Point(590, 246)
        TextBoxGrade.Name = "TextBoxGrade"
        TextBoxGrade.ReadOnly = True
        TextBoxGrade.Size = New Size(100, 23)
        TextBoxGrade.TabIndex = 15
        ' 
        ' ButtonCalculate
        ' 
        ButtonCalculate.Font = New Font("Segoe UI", 12F)
        ButtonCalculate.Location = New Point(246, 384)
        ButtonCalculate.Name = "ButtonCalculate"
        ButtonCalculate.Size = New Size(125, 44)
        ButtonCalculate.TabIndex = 16
        ButtonCalculate.Text = "Calculate"
        ButtonCalculate.UseVisualStyleBackColor = True
        ' 
        ' ButtonExit
        ' 
        ButtonExit.Font = New Font("Segoe UI", 12F)
        ButtonExit.Location = New Point(590, 384)
        ButtonExit.Name = "ButtonExit"
        ButtonExit.Size = New Size(125, 44)
        ButtonExit.TabIndex = 17
        ButtonExit.Text = "Exit"
        ButtonExit.UseVisualStyleBackColor = True
        ' 
        ' TextBoxRemarks
        ' 
        TextBoxRemarks.ForeColor = Color.Red
        TextBoxRemarks.Location = New Point(590, 303)
        TextBoxRemarks.Name = "TextBoxRemarks"
        TextBoxRemarks.ReadOnly = True
        TextBoxRemarks.Size = New Size(100, 23)
        TextBoxRemarks.TabIndex = 18
        ' 
        ' LabelRemarks
        ' 
        LabelRemarks.AutoSize = True
        LabelRemarks.Location = New Point(480, 319)
        LabelRemarks.Name = "LabelRemarks"
        LabelRemarks.Size = New Size(52, 15)
        LabelRemarks.TabIndex = 19
        LabelRemarks.Text = "Remarks"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 20F)
        Label8.ForeColor = Color.SaddleBrown
        Label8.Location = New Point(310, 33)
        Label8.Name = "Label8"
        Label8.Size = New Size(319, 37)
        Label8.TabIndex = 20
        Label8.Text = "KARE CGPA CALCULATOR"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.ErrorImage = Nothing
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.InitialImage = Nothing
        PictureBox1.Location = New Point(222, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(82, 74)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 21
        PictureBox1.TabStop = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(PictureBox1)
        Controls.Add(Label8)
        Controls.Add(LabelRemarks)
        Controls.Add(TextBoxRemarks)
        Controls.Add(ButtonExit)
        Controls.Add(ButtonCalculate)
        Controls.Add(TextBoxGrade)
        Controls.Add(TextBoxAverage)
        Controls.Add(TextBoxTotal)
        Controls.Add(TextBoxSubject5)
        Controls.Add(TextBoxSubject4)
        Controls.Add(TextBoxSubject3)
        Controls.Add(TextBoxSubject2)
        Controls.Add(TextBoxSubject1)
        Controls.Add(GradeLabel)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents GradeLabel As Label
    Friend WithEvents TextBoxSubject1 As TextBox
    Friend WithEvents TextBoxSubject2 As TextBox
    Friend WithEvents TextBoxSubject3 As TextBox
    Friend WithEvents TextBoxSubject4 As TextBox
    Friend WithEvents TextBoxSubject5 As TextBox
    Friend WithEvents TextBoxTotal As TextBox
    Friend WithEvents TextBoxAverage As TextBox
    Friend WithEvents TextBoxGrade As TextBox
    Friend WithEvents ButtonCalculate As Button
    Friend WithEvents ButtonExit As Button
    Friend WithEvents TextBoxRemarks As TextBox
    Friend WithEvents LabelRemarks As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox1 As PictureBox

End Class
