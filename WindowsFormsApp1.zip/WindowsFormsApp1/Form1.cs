﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Validate Total Classes input
            if (!int.TryParse(txtTotalClasses.Text, out int totalClasses) || totalClasses <= 0)
            {
                MessageBox.Show("Enter a valid number for Total Classes!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate Attended Classes input
            if (!int.TryParse(txtAttended.Text, out int attendedClasses) || attendedClasses < 0 || attendedClasses > totalClasses)
            {
                MessageBox.Show("Attended classes must be between 0 and Total Classes!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calculate absent classes
            int absentClasses = totalClasses - attendedClasses;
            lblAbsent.Text = $"Absent Classes: {absentClasses}";

            // Call the function to calculate attendance percentage
            CalculateAttendance(totalClasses, attendedClasses, absentClasses);
        }

        private void CalculateAttendance(int totalClasses, int attendedClasses, int absentClasses)
        {
            // Base percentage calculation
            double basePercentage = (attendedClasses / (double)totalClasses) * 100;

            // Apply adjustments
            double bonus = attendedClasses * 0.75;  // +0.75% per attended class
            double penalty = absentClasses * 2.0;   // -2% per absent class

            double finalPercentage = basePercentage + bonus - penalty;

            // Ensure final percentage is between 0% and 100%
            finalPercentage = Math.Max(0, Math.Min(100, finalPercentage));

            // Display the final attendance percentage
            lblResult.Text = $"{finalPercentage:F2}%";
        }

        private void txtresult_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
